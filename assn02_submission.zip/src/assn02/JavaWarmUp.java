package assn02;
import java.util.Scanner;
import java.lang.Math;

public class JavaWarmUp {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);

        String[] categoriesList = {"phone", "laptop", "smart_watch"};

        int n = s.nextInt();

        // Date Time1 Category Fee Quantity Time2 AsmCost
        String date[] = new String[n];
        String time1[] = new String[n];
        String category[] = new String[n];
        double fee[] = new double[n];
        int quantity[] = new int[n];
        double time2[] = new double[n];
        double asmCost[] = new double[n];

        // TODO: Fill in the above arrays with data entered from the console.
        for (int i = 0; i < n; i++) {
            date[i] = s.next();
            time1[i] = s.next();
            category[i] = s.next();
            fee[i] = Math.round(s.nextDouble());
            quantity[i] = Math.round(s.nextInt());
            time2[i] = Math.round(s.nextDouble());
            asmCost[i] = Math.round(s.nextDouble());
        }


        // Find items with highest and lowest price per unit
        int highestItemIndex = getMaxPriceIndex(fee);
        int lowestItemIndex = getMinPriceIndex(fee);

        System.out.println(date[lowestItemIndex]);
        System.out.println(time1[lowestItemIndex]);
        System.out.println(category[lowestItemIndex]);
        System.out.println(fee[lowestItemIndex]);


        System.out.println(date[highestItemIndex]);
        System.out.println(time1[highestItemIndex]);
        System.out.println(category[highestItemIndex]);
        System.out.println(fee[highestItemIndex]);

        // Calculate the # of batches, total Fee, total Quantity, total Labor and Assembly costs by category.
        // Maintain following category-wise total stats in the following Category Arrays
        int[] numOfBatchesC = new int[categoriesList.length];// so numOfBatchesC[0] = # of batches in category categoriesList[0]
        double[] totFeeC = new double[categoriesList.length]; // total fee of each category = sum(fee * qty)
        int[] totQuantityC = new int[categoriesList.length];    // total qty of each category = sum (qty)
        double[] totLaborCostC = new double[categoriesList.length]; // total labor cost of each category = sum(time2 x 16)
        double[] totAsmCostC = new double[categoriesList.length]; // total Assembly cost of each category = sum(AsmCost)

        // TODO: for each item i, incrementally total the values in the above arrays
        for (int i = 0; i < n; i++) {
            int catIndex = 0;
            if (category[i].equals("phone")) {
                catIndex = 0;
            } else if (category[i].equals("laptop")) {
                catIndex = 1;
            } else if (category[i].equals("smart_watch")) {
                catIndex = 2;
            }
            numOfBatchesC[catIndex]++;

            double indexTotalFee = fee[i] * quantity[i];
            totFeeC[catIndex] += indexTotalFee;

            totQuantityC[catIndex] += quantity[i];

            double totalLaborCost = time2[i] * 16;
            totLaborCostC[catIndex] += totalLaborCost;

            totAsmCostC[catIndex] += asmCost[i];
        }

        // TODO: Calculate & Print Category-wise Statistics
        for (int j = 0; j < categoriesList.length; j++) {
            if (numOfBatchesC[j] > 0) {
                System.out.println(categoriesList[j]);

                System.out.println(totQuantityC[j]);

                double averageFee = totFeeC[j] / numOfBatchesC[j];
                System.out.println(averageFee);

                double netProfit = totFeeC[j] - (totAsmCostC[j] + totLaborCostC[j]);
                System.out.println(netProfit);






            }

        }

    }

    static int getMaxPriceIndex(double[] price) {
        int maxPrice = 0;
        for (int i = 0; i < price.length; i++) {
            if (price[i] >= price[maxPrice]) {
                maxPrice = i;
            }
        }
        return (maxPrice);
    }

    static int getMinPriceIndex(double[] price) {
        int minPrice = 0;
        for (int i = 0; i < price.length; i++) {
            if (price[i] <= price[minPrice]) {
                minPrice = i;
            }
        }
        return (minPrice);
    }
}
